package br.com.fiap.spring_mvc.controller;

import br.com.fiap.spring_mvc.model.Livro;
import br.com.fiap.spring_mvc.model.Categoria;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {

    @GetMapping("/ola")
    public String hello(Model model) {
        model.addAttribute("message", "Hello world!");
        return "hello";
    }

    @GetMapping("/ola2")
    public ModelAndView helo2() {
        ModelAndView mv = new ModelAndView("hello");
        mv.addObject("message", "Hellooooooo");
        return mv;
    }

    @GetMapping("/livro")
    public ModelAndView livro() {
        // Criando o objeto Livro
        Livro livro = new Livro();
        livro.setAutor("Homero");
        livro.setTitulo("Odisseia");
        livro.setCategoria(Categoria.ROMANCE);

        // Adicionando o livro à view
        ModelAndView mv = new ModelAndView("livro");
        mv.addObject("livro", livro);
        return mv;
    }
}
